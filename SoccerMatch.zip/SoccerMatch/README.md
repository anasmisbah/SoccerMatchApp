# SoccerMatchApp
Aplikasi Soccer Match Schedule 

Aplikasi Submission KADE (Kotlin Android Developer Expert) DICODING x IDCAMP (Indosat Ooredoo Digital Camp) 2019.
