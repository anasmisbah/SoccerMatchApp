package com.example.soccermatch.utils

const val EXTRA_LEAGUE = "EXTRA_LEAGUE"
const val EXTRA_MATCH = "EXTRA_MATCH"
const val ENDPOINT_DETAIL_LEAGUE = "lookupleague.php"
const val ENDPOINT_LEAGUE_NEXT_EVENT ="eventsnextleague.php"
const val ENDPOINT_LEAGUE_PREVIOUS_EVENT ="eventspastleague.php"
const val ENDPOINT_DETAIL_MATCH = "lookupevent.php"
const val ENDPOINT_SEARCH_MATCH = "searchevents.php"
const val ENDPOINT_DETAIL_TEAM = "lookupteam.php"