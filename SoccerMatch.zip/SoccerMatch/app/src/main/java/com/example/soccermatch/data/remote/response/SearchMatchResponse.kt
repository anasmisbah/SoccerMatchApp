package com.example.soccermatch.data.remote.response

data class SearchMatchResponse(
    val event: List<EventResponse>
)